import logo from './logo.svg';
import './App.css';
const element = <h1>Hello World</h1>
function App() {
  return (
    <div className="App">
      {element}
    </div>
  );
}

export default App;
